import type { QuestionType } from "../components/Question";

export const questions: QuestionType[] = [
  {
    question: "SITCON 的全名是什麼？",
    options: [
      "Students' Information Technology Conference",
      "Software Innovation Technology Conference",
      "Science and Information Technology Conference",
      "Students' Innovation and Technology Conference",
    ],
    correctAnswer: 0,
    explanation:
      "SITCON 全名為 Students' Information Technology Conference，是由學生自發組織的資訊技術研討會。",
  },
  {
    question: "下列哪一項不是 SITCON 的核心價值？",
    options: ["學生與創新", "開源精神", "商業利益", "知識分享"],
    correctAnswer: 2,
    explanation:
      "SITCON 的核心價值包括學生與創新、開源精神和知識分享，而非商業利益。",
  },
  {
    question: "SITCON 年會通常在一年中的哪個季節舉辦？",
    options: ["春季", "夏季", "秋季", "冬季"],
    correctAnswer: 0,
    explanation: "SITCON 年會通常在每年的春季（3月左右）舉辦。",
  },
  {
    question: "下列哪一項技術不屬於前端開發？",
    options: ["React", "Vue.js", "Django", "Angular"],
    correctAnswer: 2,
    explanation:
      "Django 是一個 Python 後端框架，而 React、Vue.js 和 Angular 都是前端框架。",
  },
  {
    question: "Git 中，用來將更改添加到暫存區的命令是？",
    options: ["git commit", "git push", "git add", "git pull"],
    correctAnswer: 2,
    explanation:
      "git add 命令用於將更改添加到暫存區，然後可以使用 git commit 提交這些更改。",
  },
  {
    question: "下列哪種程式語言是解釋型語言？",
    options: ["C++", "Java", "Python", "Rust"],
    correctAnswer: 2,
    explanation:
      "Python 是一種解釋型語言，而 C++、Java 和 Rust 都是編譯型語言。",
  },
  {
    question: "HTTP 狀態碼 404 表示什麼？",
    options: ["請求成功", "未授權", "資源未找到", "伺服器錯誤"],
    correctAnswer: 2,
    explanation: "HTTP 狀態碼 404 表示「資源未找到」，即請求的資源不存在。",
  },
  {
    question: "下列哪一項不是 JavaScript 的資料型別？",
    options: ["String", "Boolean", "Integer", "Object"],
    correctAnswer: 2,
    explanation:
      "JavaScript 沒有 Integer 型別，而是使用 Number 型別來表示整數和浮點數。",
  },
  {
    question: "開源軟體的英文縮寫是？",
    options: ["OSS", "OPS", "OOS", "OFS"],
    correctAnswer: 0,
    explanation: "開源軟體的英文縮寫是 OSS (Open Source Software)。",
  },
  {
    question: "下列哪一項不是常見的資料庫系統？",
    options: ["MySQL", "MongoDB", "PostgreSQL", "ReactDB"],
    correctAnswer: 3,
    explanation:
      "ReactDB 不是一個真實的資料庫系統，而 MySQL、MongoDB 和 PostgreSQL 都是常見的資料庫系統。",
  },
];
